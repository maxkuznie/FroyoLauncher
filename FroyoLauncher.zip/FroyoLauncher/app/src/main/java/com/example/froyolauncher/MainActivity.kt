package com.example.froyolauncher

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** A Froyo-style home screen: search bar on top, 3-icon dock, black app drawer. */
class MainActivity : Activity() {

    private val apps = ArrayList<ResolveInfo>()
    private val appAdapter = AppAdapter()
    private lateinit var home: FrameLayout
    private lateinit var drawer: FrameLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun match() = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        home = buildHome()
        drawer = buildDrawer()
        val root = FrameLayout(this)
        root.addView(home, match())
        root.addView(drawer, match())
        // Android 15 forces edge-to-edge, so keep our UI clear of the system bars.
        root.setOnApplyWindowInsetsListener { _, insets ->
            val b = insets.getInsets(WindowInsets.Type.systemBars())
            home.setPadding(b.left, b.top, b.right, b.bottom)
            drawer.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        setContentView(root)
    }

    private fun buildHome(): FrameLayout {
        val f = FrameLayout(this)

        val search = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(14), 0)
            background = GradientDrawable().apply {
                setColor(0xE6EEEEEE.toInt())
                cornerRadius = dp(6).toFloat()
            }
            addView(ImageView(context).apply {
                setImageResource(android.R.drawable.ic_menu_search)
            }, LinearLayout.LayoutParams(dp(24), dp(24)))
            addView(TextView(context).apply {
                text = "Search"
                textSize = 16f
                setTextColor(0xFF555555.toInt())
                setPadding(dp(10), 0, 0, 0)
            })
            setOnClickListener { launch(Intent(Intent.ACTION_WEB_SEARCH)) }
        }
        f.addView(search, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(48), Gravity.TOP
        ).apply { setMargins(dp(12), dp(12), dp(12), 0) })

        val dock = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x00000000, 0xAA000000.toInt())
            )
        }
        dock.addView(dockIcon(intentIcon(Intent(Intent.ACTION_DIAL))) {
            launch(Intent(Intent.ACTION_DIAL))
        })
        dock.addView(dockIcon(GridDotsDrawable()) { setDrawer(true) })
        dock.addView(dockIcon(intentIcon(Intent(Intent.ACTION_VIEW, Uri.parse("https://")))) {
            launch(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER))
        })
        f.addView(dock, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
        ))
        return f
    }

    private fun buildDrawer(): FrameLayout {
        val f = FrameLayout(this).apply {
            setBackgroundColor(0xF2000000.toInt())
            visibility = View.GONE
            isClickable = true
        }
        val grid = GridView(this).apply {
            numColumns = 4
            verticalSpacing = dp(16)
            setPadding(dp(8), dp(16), dp(8), dp(16))
            clipToPadding = false
            setSelector(android.R.color.transparent)
            adapter = appAdapter
            setOnItemClickListener { _, _, pos, _ -> openApp(apps[pos]) }
        }
        f.addView(grid, match())
        return f
    }

    private fun dockIcon(icon: Drawable?, onClick: () -> Unit) = ImageView(this).apply {
        setImageDrawable(icon)
        setPadding(dp(8), dp(8), dp(8), dp(8))
        layoutParams = LinearLayout.LayoutParams(dp(64), dp(64)).apply {
            setMargins(dp(14), 0, dp(14), 0)
        }
        setOnClickListener { onClick() }
    }

    private fun intentIcon(i: Intent): Drawable? =
        packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
            ?.loadIcon(packageManager)

    @Suppress("DEPRECATION")
    private fun loadApps() {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val sorted = pm.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { it to it.loadLabel(pm).toString().lowercase() }
            .sortedBy { it.second }
            .map { it.first }
        apps.clear()
        apps.addAll(sorted)
        appAdapter.notifyDataSetChanged()
    }

    private fun openApp(ri: ResolveInfo) {
        val a = ri.activityInfo
        launch(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(a.packageName, a.name)
                .addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        )
        setDrawer(false)
    }

    private fun launch(i: Intent) {
        try {
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }

    private fun setDrawer(show: Boolean) {
        if (show) {
            loadApps()
            drawer.alpha = 0f
            drawer.visibility = View.VISIBLE
            drawer.animate().alpha(1f).setDuration(200).start()
        } else if (drawer.visibility == View.VISIBLE) {
            drawer.animate().alpha(0f).setDuration(150)
                .withEndAction { drawer.visibility = View.GONE }.start()
        }
    }

    // A launcher never finishes on Back; it just closes the drawer.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = setDrawer(false)

    // Pressing Home while the drawer is open returns to the home screen.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) setDrawer(false)
    }

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(position: Int) = apps[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val cell = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                addView(ImageView(context), LinearLayout.LayoutParams(dp(48), dp(48)))
                addView(TextView(context).apply {
                    setTextColor(Color.WHITE)
                    textSize = 12f
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER
                    setPadding(dp(2), dp(4), dp(2), 0)
                })
            }
            val pm = packageManager
            (cell.getChildAt(0) as ImageView).setImageDrawable(apps[position].loadIcon(pm))
            (cell.getChildAt(1) as TextView).text = apps[position].loadLabel(pm)
            return cell
        }
    }
}

/** The 3x3 dot grid used for the app-drawer button. */
class GridDotsDrawable : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val s = minOf(b.width(), b.height()) / 4f
        val ox = b.exactCenterX() - s * 2
        val oy = b.exactCenterY() - s * 2
        for (i in 1..3) for (j in 1..3) canvas.drawCircle(ox + s * i, oy + s * j, s / 4f, paint)
    }

    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(colorFilter: ColorFilter?) { paint.colorFilter = colorFilter }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}
